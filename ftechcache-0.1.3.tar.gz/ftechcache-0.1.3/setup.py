import setuptools
from setuptools import setup
setup(
    name='ftechcache',
    version='0.1.3',
    description='Custom Django cache by Long Ftech',
    url='https://ftech.ai',
    author='longphung',
    author_email='longpd@ftech.ai',
    license='MIT',
    packages= setuptools.find_packages(),
    zip_safe=False
)