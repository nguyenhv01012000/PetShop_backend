from django.conf import settings
from django.middleware.cache import UpdateCacheMiddleware, FetchFromCacheMiddleware
from django.utils.cache import (
    get_cache_key, get_max_age, learn_cache_key,
    patch_response_headers,
)
from rest_framework.authentication import (
    get_authorization_header,
)
from django.core.cache import DEFAULT_CACHE_ALIAS, caches
import logging
from rest_framework import exceptions
import redis
from redis import ConnectionError
from core.utils import GenCacheKey
class MyUpdateCacheMiddleware(UpdateCacheMiddleware):
    def process_response(self, request, response):
        if not self._should_update_cache(request, response):
            return response
        
        if response.streaming or response.status_code not in (200, 304):
            return response

        timeout = self.page_timeout
        if timeout is None:
            # The timeout from the "max-age" section of the "Cache-Control"
            # header takes precedence over the default cache timeout.
            timeout = get_max_age(response)
            if timeout is None:
                timeout = self.cache_timeout
            elif timeout == 0:
                # max-age was set to 0, don't cache.
                return response
        key_prefix = GenCacheKey(request)
        if key_prefix.key_prefix is None:
            key_prefix.key_prefix = request.path      
        patch_response_headers(response, timeout)
        if timeout and response.status_code == 200:
            cache_key = learn_cache_key(request, response, timeout, key_prefix.key_prefix, cache=self.cache)
            if hasattr(response, 'render') and callable(response.render):
                response.add_post_render_callback(
                    lambda r: self.cache.set(cache_key, r, timeout)
                )
            else:
                self.cache.set(cache_key, response, timeout)
        return response

class MyFtechCacheMiddleware(FetchFromCacheMiddleware):
    def process_request(self, request): 
        if request.method not in ('GET', 'HEAD'):
            request._cache_update_cache = False
            return None  # Don't bother checking the cache.
        cache_control = request.headers.get("Cache-Control", None)
        if cache_control is not None:
            cache_control= cache_control.replace(" ", "")
            cache_control =  cache_control.split(",")
            if "no-store" not in cache_control and "no-cache" in cache_control:
                request._cache_update_cache = False
                return None  # No cache in request.      
        key_prefix = GenCacheKey(request)
        if key_prefix.key_prefix is None:
            key_prefix.key_prefix = request.path
        if key_prefix.key_prefix == "nocache":
            request._cache_update_cache = False
            return None  # No cache in create.
        # try and get the cached GET response
        cache_key = get_cache_key(request, key_prefix.key_prefix, 'GET', cache=self.cache) 
        if cache_key is None:
            request._cache_update_cache = True
            return None  # No cache information available, need to rebuild.     
        response = self.cache.get(cache_key)
        # if it wasn't found and we are looking for a HEAD, try looking just for that
        if response is None and request.method == 'HEAD':
            cache_key = get_cache_key(request, key_prefix, 'HEAD', cache=self.cache)
            response = self.cache.get(cache_key)
        if response is None:
            request._cache_update_cache = True
            return None  # No cache information available, need to rebuild.
        # hit, return cached response
        request._cache_update_cache = False
        return response
