from functools import wraps
from django.views.decorators.cache import cache_page
from apps.users.models import User, Staff
 
def cache_on_auth(timeout, key_prefix=''):
   def decorator(view_func):
       @wraps(view_func)
       def _wrapped_view(request, *args, **kwargs):
            user_unique_id = ''
            user = request.user
            if isinstance(user, User):
                user_unique_id = "User_%s" % user.id
            elif isinstance(user, Staff):
                user_unique_id = "Staff_%s" % user.id
            else:
                pass
            return cache_page(timeout, key_prefix="%s_auth_%s" % (key_prefix, user_unique_id))(view_func)(request, *args, **kwargs)
       return _wrapped_view
   return decorator